<?php
ob_start();
ob_end_flush();
include("config.php");
include("inc/func/functions.php");
$tmp = "inc/tmp";
$css = "src/css";
$plugins = "src/plugins";
$img = "src/img";
$js = "src/js";


?>