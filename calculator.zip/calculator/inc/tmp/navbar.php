<!-- شريط التنقل -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- روابط شريط التنقل اليسارية -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
        
        <li class="nav-item d-none d-sm-inline-block">
            <a href="logout.php" class="nav-link">تسجيل خروج</a>
        </li>
    </ul>

    <!-- نموذج البحث -->
   

    <!-- روابط شريط التنقل اليمنى -->
    
</nav>
<!-- /شريط التنقل -->
